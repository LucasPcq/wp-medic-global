/* global jQuery:false */

(function() {
	"use strict";
	jQuery(document).trigger('action.init_hidden_elements', [jQuery('.vc_edit_form_elements')]);

})();