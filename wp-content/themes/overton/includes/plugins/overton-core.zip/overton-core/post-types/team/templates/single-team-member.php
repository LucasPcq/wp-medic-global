<?php

get_header();

overton_mikado_get_title();

do_action('overton_mikado_action_before_main_content');

overton_core_get_single_team();

get_footer();