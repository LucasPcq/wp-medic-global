<?php

if ( ! function_exists( 'overton_mikado_portfolio_category_additional_fields' ) ) {
	function overton_mikado_portfolio_category_additional_fields() {
		
		$fields = overton_mikado_add_taxonomy_fields(
			array(
				'scope' => 'portfolio-category',
				'name'  => 'portfolio_category_options'
			)
		);
		
		overton_mikado_add_taxonomy_field(
			array(
				'name'   => 'mkdf_portfolio_category_image_meta',
				'type'   => 'image',
				'label'  => esc_html__( 'Category Image', 'overton-core' ),
				'parent' => $fields
			)
		);
	}
	
	add_action( 'overton_mikado_action_custom_taxonomy_fields', 'overton_mikado_portfolio_category_additional_fields' );
}