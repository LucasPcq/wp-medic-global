<div class="mkdf-team-single-info-holder">
	<div class="mkdf-grid-row">
		<div class="mkdf-ts-image-holder mkdf-grid-col-6">
			<?php the_post_thumbnail('overton_mikado_image_square'); ?>
		</div>
		<div class="mkdf-ts-details-holder mkdf-grid-col-6">
			<h3 itemprop="name" class="mkdf-name entry-title"><?php the_title(); ?></h3>
            <div class="mkdf-team-single-content">
				<?php the_content(); ?>
            </div>
			<div class="mkdf-ts-bio-holder">
				<?php if(!empty($fields)) { ?>
                    <div class="mkdf-position">
                        <h6 aria-hidden="true" class="mkdf-team-info-title"><?php echo esc_html__('Fields of work:', 'overton-core')?></h6>
						<?php echo esc_html($fields); ?>
                    </div>
				<?php } ?>
				<?php if(!empty($clients)) { ?>
                    <div class="mkdf-position">
                        <h6 aria-hidden="true" class="mkdf-team-info-title"><?php echo esc_html__('Clients:', 'overton-core')?></h6>
						<?php echo esc_html($clients); ?>
                    </div>
				<?php } ?>
				<?php if(!empty($position)) { ?>
                    <div class="mkdf-position">
                        <h6 aria-hidden="true" class="mkdf-team-info-title"><?php echo esc_html__('Position:', 'overton-core')?></h6>
						<?php echo esc_html($position); ?>
                    </div>
				<?php } ?>
				<?php if(!empty($birth_date)) { ?>
					<div class="mkdf-ts-info-row">
						<span aria-hidden="true" class="icon_calendar mkdf-ts-bio-icon"></span>
						<span class="mkdf-ts-bio-info"><?php echo esc_html__('born on: ', 'overton-core').esc_html($birth_date); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($email)) { ?>
					<div class="mkdf-ts-info-row">
						<span aria-hidden="true" class="icon_mail_alt mkdf-ts-bio-icon"></span>
						<span itemprop="email" class="mkdf-ts-bio-info"><?php echo esc_html__('email: ', 'overton-core').sanitize_email(esc_html($email)); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($phone)) { ?>
					<div class="mkdf-ts-info-row">
						<span aria-hidden="true" class="icon_phone mkdf-ts-bio-icon"></span>
						<span class="mkdf-ts-bio-info"><?php echo esc_html__('phone: ', 'overton-core').esc_html($phone); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($address)) { ?>
					<div class="mkdf-ts-info-row">
						<span aria-hidden="true" class="icon_building_alt mkdf-ts-bio-icon"></span>
						<span class="mkdf-ts-bio-info"><?php echo esc_html__('lives in: ', 'overton-core').esc_html($address); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($education)) { ?>
					<div class="mkdf-ts-info-row">
						<span aria-hidden="true" class="icon_ribbon_alt mkdf-ts-bio-icon"></span>
						<span class="mkdf-ts-bio-info"><?php echo esc_html__('education: ', 'overton-core').esc_html($education); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($resume)) { ?>
					<div class="mkdf-ts-info-row">
						<span aria-hidden="true" class="icon_document_alt mkdf-ts-bio-icon"></span>
						<a href="<?php echo esc_url($resume); ?>" download target="_blank"><span class="mkdf-ts-bio-info"><?php echo esc_html__('Download Resume', 'overton-core'); ?></span></a>
					</div>
				<?php } ?>
			</div>
            <div class="mkdf-team-social-holder">
                <?php foreach ($social_icons as $social_icon) {
                    echo wp_kses_post($social_icon);
                } ?>
            </div>
		</div>
	</div>
</div>