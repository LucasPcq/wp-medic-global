(function($) {
    'use strict';

    var portfolioSlider = {};
    mkdf.modules.portfolioSlider = portfolioSlider;

    portfolioSlider.mkdfOnWindowLoad = mkdfOnWindowLoad;

    $(window).load(mkdfOnWindowLoad);

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function mkdfOnWindowLoad() {
        mkdfInitPortfolioSliderItemCentering();
    }

    /**
     * Portfolio slider item click and navigation behaviour
     * NOTE: owl slider center option must be set to true
     */
    function mkdfInitPortfolioSliderItemCentering(){
        var portfolioSliderHolder = $('.mkdf-portfolio-slider-holder');

        if(portfolioSliderHolder.length){
            portfolioSliderHolder.each(function(){
                
                var thisPortSliderHolder = $(this),
                    thisPortSlider = thisPortSliderHolder.find('.mkdf-owl-slider'),
                    thisSliderNavigation = thisPortSlider.find('.owl-nav'),
                    thisSliderData = thisPortSlider.data('owl.carousel');

                // Append slider navigation to portfolio slider holder
                thisPortSliderHolder.append(thisSliderNavigation);
                thisSliderNavigation.addClass('mkdf-owl-custom-navigation');
                
                // Item click centering
                thisPortSlider.on('click', '.owl-item', function(e) {
                    if (($(this).hasClass('center'))) {
                        // item is centered
                    } else {
                        e.preventDefault();
                        e.stopPropagation();
                        // move item to center
                        thisSliderData.to(thisSliderData.relative($(this).index()));
                    }
                });
            });
        }
    }
})(jQuery);