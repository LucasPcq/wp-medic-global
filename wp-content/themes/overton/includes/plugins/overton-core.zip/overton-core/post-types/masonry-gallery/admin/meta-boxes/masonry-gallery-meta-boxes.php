<?php

if ( ! function_exists( 'overton_core_map_masonry_gallery_meta' ) ) {
	function overton_core_map_masonry_gallery_meta() {
		
		$masonry_gallery_meta_box = overton_mikado_create_meta_box(
			array(
				'scope' => array( 'masonry-gallery' ),
				'title' => esc_html__( 'Masonry Gallery General', 'overton-core' ),
				'name'  => 'masonry_gallery_meta'
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'          => 'mkdf_masonry_gallery_item_title_tag',
				'type'          => 'select',
				'default_value' => 'h4',
				'label'         => esc_html__( 'Title Tag', 'overton-core' ),
				'parent'        => $masonry_gallery_meta_box,
				'options'       => overton_mikado_get_title_tag()
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'   => 'mkdf_masonry_gallery_item_text',
				'type'   => 'text',
				'label'  => esc_html__( 'Text', 'overton-core' ),
				'parent' => $masonry_gallery_meta_box
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'   => 'mkdf_masonry_gallery_item_image',
				'type'   => 'image',
				'label'  => esc_html__( 'Custom Item Icon', 'overton-core' ),
				'parent' => $masonry_gallery_meta_box
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'   => 'mkdf_masonry_gallery_item_link',
				'type'   => 'text',
				'label'  => esc_html__( 'Link', 'overton-core' ),
				'parent' => $masonry_gallery_meta_box
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'          => 'mkdf_masonry_gallery_item_link_target',
				'type'          => 'select',
				'default_value' => '_self',
				'label'         => esc_html__( 'Link Target', 'overton-core' ),
				'parent'        => $masonry_gallery_meta_box,
				'options'       => overton_mikado_get_link_target_array()
			)
		);
		
		overton_mikado_add_admin_section_title( array(
			'name'   => 'mkdf_section_style_title',
			'parent' => $masonry_gallery_meta_box,
			'title'  => esc_html__( 'Masonry Gallery Item Style', 'overton-core' )
		) );
		
		overton_mikado_create_meta_box_field(
			array(
				'name'          => 'mkdf_masonry_gallery_item_size',
				'type'          => 'select',
				'default_value' => 'small',
				'label'         => esc_html__( 'Size', 'overton-core' ),
				'parent'        => $masonry_gallery_meta_box,
				'options'       => array(
					'small'              => esc_html__( 'Small', 'overton-core' ),
					'large-width'        => esc_html__( 'Large Width', 'overton-core' ),
					'large-height'       => esc_html__( 'Large Height', 'overton-core' ),
					'large-width-height' => esc_html__( 'Large Width/Height', 'overton-core' )
				)
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'          => 'mkdf_masonry_gallery_item_type',
				'type'          => 'select',
				'default_value' => 'standard',
				'label'         => esc_html__( 'Type', 'overton-core' ),
				'parent'        => $masonry_gallery_meta_box,
				'options'       => array(
					'standard'    => esc_html__( 'Standard', 'overton-core' ),
					'with-button' => esc_html__( 'With Button', 'overton-core' ),
					'simple'      => esc_html__( 'Simple', 'overton-core' )
				)
			)
		);
		
		$masonry_gallery_item_button_type_container = overton_mikado_add_admin_container_no_style(
			array(
				'name'            => 'masonry_gallery_item_button_type_container',
				'parent'          => $masonry_gallery_meta_box,
				'dependency' => array(
					'hide' => array(
						'mkdf_masonry_gallery_item_type'  => array( 'standard', 'simple' )
					)
				)
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'   => 'mkdf_masonry_gallery_button_label',
				'type'   => 'text',
				'label'  => esc_html__( 'Button Label', 'overton-core' ),
				'parent' => $masonry_gallery_item_button_type_container
			)
		);
		
		$masonry_gallery_item_simple_type_container = overton_mikado_add_admin_container_no_style(
			array(
				'name'            => 'masonry_gallery_item_simple_type_container',
				'parent'          => $masonry_gallery_meta_box,
				'dependency' => array(
					'hide' => array(
						'mkdf_masonry_gallery_item_type'  => array( 'standard', 'with-button' )
					)
				)
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'          => 'mkdf_masonry_gallery_simple_content_background_skin',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Content Background Skin', 'overton-core' ),
				'parent'        => $masonry_gallery_item_simple_type_container,
				'options'       => array(
					'default' => esc_html__( 'Default', 'overton-core' ),
					'light'   => esc_html__( 'Light', 'overton-core' ),
					'dark'    => esc_html__( 'Dark', 'overton-core' )
				)
			)
		);
	}
	
	add_action( 'overton_mikado_action_meta_boxes_map', 'overton_core_map_masonry_gallery_meta', 45 );
}