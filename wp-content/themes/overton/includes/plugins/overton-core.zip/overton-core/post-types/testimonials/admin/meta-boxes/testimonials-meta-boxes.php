<?php

if ( ! function_exists( 'overton_core_map_testimonials_meta' ) ) {
	function overton_core_map_testimonials_meta() {
		$testimonial_meta_box = overton_mikado_create_meta_box(
			array(
				'scope' => array( 'testimonials' ),
				'title' => esc_html__( 'Testimonial', 'overton-core' ),
				'name'  => 'testimonial_meta'
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'        => 'mkdf_testimonial_title',
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'overton-core' ),
				'description' => esc_html__( 'Enter testimonial title', 'overton-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'        => 'mkdf_testimonial_text',
				'type'        => 'text',
				'label'       => esc_html__( 'Text', 'overton-core' ),
				'description' => esc_html__( 'Enter testimonial text', 'overton-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'        => 'mkdf_testimonial_author',
				'type'        => 'text',
				'label'       => esc_html__( 'Author', 'overton-core' ),
				'description' => esc_html__( 'Enter author name', 'overton-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		overton_mikado_create_meta_box_field(
			array(
				'name'        => 'mkdf_testimonial_author_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Author Position', 'overton-core' ),
				'description' => esc_html__( 'Enter author job position', 'overton-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
	}
	
	add_action( 'overton_mikado_action_meta_boxes_map', 'overton_core_map_testimonials_meta', 95 );
}