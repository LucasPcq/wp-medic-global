<div class="mkdf-team-list-holder mkdf-grid-list mkdf-disable-bottom-space <?php echo esc_attr($holder_classes); ?>">
	<div class="mkdf-tl-inner mkdf-outer-space <?php echo esc_attr($inner_classes); ?>" <?php echo overton_mikado_get_inline_attrs($data_attrs); ?>>
		<?php
			if($query_results->have_posts()):
				while ( $query_results->have_posts() ) : $query_results->the_post();
					$params['member_id'] = get_the_ID();
					echo overton_mikado_execute_shortcode('mkdf_team_member', $params);
				endwhile;
			else:
				esc_html_e( 'Sorry, no posts matched your criteria.', 'overton-core' );
			endif;
		
			wp_reset_postdata();
		?>
	</div>
</div>