<div class="mkdf-testimonials-holder clearfix <?php echo esc_attr($holder_classes); ?>">
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                width="53px" height="36px" viewBox="0 0 53 36" enable-background="new 0 0 53 36" xml:space="preserve">
        <g>
            <g>
                <g>
                    <path fill="#030204" d="M14.154,2.116c6.434,0,11.673,5.236,11.673,11.674c0,6.734-6.286,16.013-11.524,20.654h-7.78
                        c1.945-2.994,3.739-6.287,4.786-9.58c-5.985-1.047-8.826-6.136-8.826-11.074C2.482,7.352,7.716,2.116,14.154,2.116z"/>
                </g>
            </g>
            <g>
                <g>
                    <path fill="#030204" d="M39.2,2.116c6.433,0,11.672,5.236,11.672,11.674c0,6.734-6.286,16.013-11.525,20.654h-7.78
                        c1.947-2.994,3.74-6.287,4.787-9.58c-5.986-1.047-8.827-6.136-8.827-11.074C27.526,7.352,32.762,2.116,39.2,2.116z"/>
                </g>
            </g>
        </g>
    </svg>
    <div class="mkdf-testimonials mkdf-owl-slider" <?php echo overton_mikado_get_inline_attrs( $data_attr ) ?>>

    <?php if ( $query_results->have_posts() ):
        while ( $query_results->have_posts() ) : $query_results->the_post();
            $title    = get_post_meta( get_the_ID(), 'mkdf_testimonial_title', true );
            $text     = get_post_meta( get_the_ID(), 'mkdf_testimonial_text', true );
            $author   = get_post_meta( get_the_ID(), 'mkdf_testimonial_author', true );
            $position = get_post_meta( get_the_ID(), 'mkdf_testimonial_author_position', true );

            $current_id = get_the_ID();
    ?>

            <div class="mkdf-testimonial-content" id="mkdf-testimonials-<?php echo esc_attr( $current_id ) ?>">
                <div class="mkdf-testimonial-text-holder">
                    <?php if ( ! empty( $title ) ) { ?>
                        <h2 itemprop="name" class="mkdf-testimonial-title entry-title"><?php echo esc_html( $title ); ?></h2>
                    <?php } ?>
                    <?php if ( ! empty( $text ) ) { ?>
                        <p class="mkdf-testimonial-text"><?php echo esc_html( $text ); ?></p>
                    <?php } ?>
                    <?php if ( ! empty( $author ) ) { ?>
                        <h5 class="mkdf-testimonial-author">
                            <span class="mkdf-testimonials-author-name"><?php echo esc_html( $author ); ?></span>
                        </h5>
                    <?php } ?>
	                <?php if ( ! empty( $position ) ) { ?>
                        <span class="mkdf-testimonials-author-job"><?php echo esc_html( $position ); ?></span>
	                <?php } ?>
                </div>
                <?php if ( has_post_thumbnail() ) { ?>
                    <div class="mkdf-testimonial-image">
                        <?php echo get_the_post_thumbnail( get_the_ID(), array( 66, 66 ) ); ?>
                    </div>
                <?php } ?>
            </div>

    <?php
        endwhile;
    else:
        echo esc_html__( 'Sorry, no posts matched your criteria.', 'overton-core' );
    endif;

    wp_reset_postdata();
    ?>

    </div>
</div>