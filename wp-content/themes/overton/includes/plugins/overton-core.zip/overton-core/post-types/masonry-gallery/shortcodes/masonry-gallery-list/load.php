<?php
require_once 'masonry-gallery.php';
require_once 'helper-functions.php';