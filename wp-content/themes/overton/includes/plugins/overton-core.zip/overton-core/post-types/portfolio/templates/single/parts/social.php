<?php if ( overton_mikado_options()->getOptionValue( 'enable_social_share' ) == 'yes' && overton_mikado_options()->getOptionValue( 'enable_social_share_on_portfolio-item' ) == 'yes' ) : ?>
	<div class="mkdf-ps-info-item mkdf-ps-social-share">
		<?php
		/**
		 * Available params type, icon_type and title
		 *
		 * Return social share html
		 */
		echo overton_mikado_get_social_share_html( array( 'type'  => 'list' ) ); ?>
	</div>
<?php endif; ?>