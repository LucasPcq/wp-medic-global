<?php

if ( ! function_exists( 'overton_core_map_portfolio_meta' ) ) {
	function overton_core_map_portfolio_meta() {
		global $overton_mikado_global_Framework;
		
		$overton_pages = array();
		$pages      = get_pages();
		foreach ( $pages as $page ) {
			$overton_pages[ $page->ID ] = $page->post_title;
		}
		
		//Portfolio Images
		
		$overton_portfolio_images = new OvertonMikadoClassMetaBox( 'portfolio-item', esc_html__( 'Portfolio Images (multiple upload)', 'overton-core' ), '', '', 'portfolio_images' );
		$overton_mikado_global_Framework->mkdMetaBoxes->addMetaBox( 'portfolio_images', $overton_portfolio_images );
		
		$overton_portfolio_image_gallery = new OvertonMikadoClassMultipleImages( 'mkdf-portfolio-image-gallery', esc_html__( 'Portfolio Images', 'overton-core' ), esc_html__( 'Choose your portfolio images', 'overton-core' ) );
		$overton_portfolio_images->addChild( 'mkdf-portfolio-image-gallery', $overton_portfolio_image_gallery );
		
		//Portfolio Single Upload Images/Videos 
		
		$overton_portfolio_images_videos = overton_mikado_create_meta_box(
			array(
				'scope' => array( 'portfolio-item' ),
				'title' => esc_html__( 'Portfolio Images/Videos (single upload)', 'overton-core' ),
				'name'  => 'mkdf_portfolio_images_videos'
			)
		);
		overton_mikado_add_repeater_field(
			array(
				'name'        => 'mkdf_portfolio_single_upload',
				'parent'      => $overton_portfolio_images_videos,
				'button_text' => esc_html__( 'Add Image/Video', 'overton-core' ),
				'fields'      => array(
					array(
						'type'        => 'select',
						'name'        => 'file_type',
						'label'       => esc_html__( 'File Type', 'overton-core' ),
						'options' => array(
							'image' => esc_html__('Image','overton-core'),
							'video' => esc_html__('Video','overton-core'),
						)
					),
					array(
						'type'        => 'image',
						'name'        => 'single_image',
						'label'       => esc_html__( 'Image', 'overton-core' ),
						'dependency' => array(
							'show' => array(
								'file_type'  => 'image'
							)
						)
					),
					array(
						'type'        => 'select',
						'name'        => 'video_type',
						'label'       => esc_html__( 'Video Type', 'overton-core' ),
						'options'	  => array(
							'youtube' => esc_html__('YouTube', 'overton-core'),
							'vimeo' => esc_html__('Vimeo', 'overton-core'),
							'self' => esc_html__('Self Hosted', 'overton-core'),
						),
						'dependency' => array(
							'show' => array(
								'file_type'  => 'video'
							)
						)
					),
					array(
						'type'        => 'text',
						'name'        => 'video_id',
						'label'       => esc_html__( 'Video ID', 'overton-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => array('youtube','vimeo')
							)
						)
					),
					array(
						'type'        => 'text',
						'name'        => 'video_mp4',
						'label'       => esc_html__( 'Video mp4', 'overton-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => 'self'
							)
						)
					),
					array(
						'type'        => 'image',
						'name'        => 'video_cover_image',
						'label'       => esc_html__( 'Video Cover Image', 'overton-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => 'self'
							)
						)
					)
				)
			)
		);
		
		//Portfolio Additional Sidebar Items
		
		$overton_additional_sidebar_items = overton_mikado_create_meta_box(
			array(
				'scope' => array( 'portfolio-item' ),
				'title' => esc_html__( 'Additional Portfolio Sidebar Items', 'overton-core' ),
				'name'  => 'portfolio_properties'
			)
		);

		overton_mikado_add_repeater_field(
			array(
				'name'        => 'mkdf_portfolio_properties',
				'parent'      => $overton_additional_sidebar_items,
				'button_text' => esc_html__( 'Add New Item', 'overton-core' ),
				'fields'      => array(
					array(
						'type'        => 'text',
						'name'        => 'item_title',
						'label'       => esc_html__( 'Item Title', 'overton-core' ),
					),
					array(
						'type'        => 'text',
						'name'        => 'item_text',
						'label'       => esc_html__( 'Item Text', 'overton-core' )
					),
					array(
						'type'        => 'text',
						'name'        => 'item_url',
						'label'       => esc_html__( 'Enter Full URL for Item Text Link', 'overton-core' )
					)
				)
			)
		);
	}
	
	add_action( 'overton_mikado_action_meta_boxes_map', 'overton_core_map_portfolio_meta', 40 );
}