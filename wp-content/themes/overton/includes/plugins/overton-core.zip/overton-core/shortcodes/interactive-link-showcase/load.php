<?php

include_once OVERTON_CORE_SHORTCODES_PATH . '/interactive-link-showcase/functions.php';
include_once OVERTON_CORE_SHORTCODES_PATH . '/interactive-link-showcase/interactive-link-showcase.php';