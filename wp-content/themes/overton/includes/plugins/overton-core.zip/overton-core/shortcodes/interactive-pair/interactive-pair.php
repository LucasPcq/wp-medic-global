<?php
namespace OvertonCore\CPT\Shortcodes\InteractivePair;

use OvertonCore\Lib;

class InteractivePair implements Lib\ShortcodeInterface {
    private $base;
	

	public function __construct() {
		$this->base = 'mkdf_interactive_pair';
		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap(){
		vc_map( array(
            'name'                    => esc_html__( 'Interactive Pair', 'overton-core' ),
            'base'                    => $this->base,
            'allowed_container_element' => 'vc_row',
            'category'                => esc_html__( 'by OVERTON', 'overton-core' ),
            'icon'                    => 'icon-wpb-elements-interactive-pair extended-custom-icon',
            'params'                  => array(
					array(
						'type' => 'attach_image',
						'admin_label' => true,
						'heading' => esc_html__('Left Box Image','overton-core'),
						'param_name' => 'image'
					),
					array(
						'type' => 'textfield',
						'admin_label' => true,
                        'heading' => esc_html__('Left Box Title','overton-core'),
						'param_name' => 'title',
						'value' => ''
					),
                array(
                    'type' => 'textfield',
                    'admin_label' => true,
                    'heading' => esc_html__('Left Box Subitle','overton-core'),
                    'param_name' => 'subtitle',
                    'value' => ''
                ),
					array(
						'type' => 'textfield',
						'admin_label' => false,
                        'heading' => esc_html__('Left Box Text','overton-core'),
						'param_name' => 'text',
						'value' => ''
					),
					array(
						'type' => 'textfield',
						'admin_label' => true,
                        'heading' => esc_html__('Left Box Link','overton-core'),
						'param_name' => 'link',
						'value' => ''
					),
                    array(
                        'type' => 'attach_image',
                        'admin_label' => true,
                        'heading' => esc_html__('Right Box Image','overton-core'),
                        'param_name' => 'image_right'
                    ),
                    array(
                        'type' => 'textfield',
                        'admin_label' => true,
                        'heading' => esc_html__('Right Box Title','overton-core'),
                        'param_name' => 'title_right',
                        'value' => ''
                    ),
                    array(
                        'type' => 'textfield',
                        'admin_label' => true,
                        'heading' => esc_html__('Right Box Subtitle','overton-core'),
                        'param_name' => 'subtitle_right',
                        'value' => ''
                    ),
                    array(
                        'type' => 'textfield',
                        'admin_label' => false,
                        'heading' => esc_html__('Right Box Text','overton-core'),
                        'param_name' => 'text_right',
                        'value' => ''
                    ),
                    array(
                        'type' => 'textfield',
                        'admin_label' => true,
                        'heading' => esc_html__('Right Box Link','overton-core'),
                        'param_name' => 'link_right',
                        'value' => ''
                    ),
			)
		) );
	}
	
	public function render($atts, $content = null) {
		
		$args = array(
            'title' => '',
            'subtitle' => '',
            'text' => '',
            'image' => '',
            'link' => 'javascrpit:void(0)',
            'title_right' => '',
            'subtitle_right' => '',
            'text_right' => '',
            'image_right' => '',
            'link_right' => 'javascrpit:void(0)',
        );

        $params  = shortcode_atts($args, $atts);
		extract($params);
		
		$params['target'] = "_self";
		$params['image_src'] = $this->getImage($params);
		$params['image_src_right'] = $this->getImageRight($params);
		$params['content'] = $content;

		$html = '<div class="mkdf-interactive-pair-holder">';
		$html .= '<div class="mkdf-interactive-pair-holder-inner clearfix">';
        $html .= overton_core_get_shortcode_module_template_part('templates/interactive-pair','interactive-pair', '', $params);
		$html .= '</div>';
		$html .= '</div>';
        return $html;
		
	}
	/**
	* Generate image src attribute
	*
	* @param $params
	*
	* @return string
	*/
	private function getImage($params){
		$image_src = '';
		if (is_numeric($params['image'])) {
            $image_src = wp_get_attachment_url($params['image']);
        } else {
            $image_src = $params['image'];
        }
		return $image_src;
	}

    private function getImageRight($params){
        $image_src = '';
        if (is_numeric($params['image_right'])) {
            $image_src = wp_get_attachment_url($params['image_right']);
        } else {
            $image_src = $params['image_right'];
        }
        return $image_src;
    }
}