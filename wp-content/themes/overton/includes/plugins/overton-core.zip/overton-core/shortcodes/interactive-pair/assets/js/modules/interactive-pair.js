(function ($) {
    'use strict';

    var interactivepair = {};
    mkdf.modules.interactivepair = interactivepair;

    interactivepair.mkdfInitInteractivePair = mkdfInitInteractivePair;


    interactivepair.mkdfOnDocumentReady = mkdfOnDocumentReady;

    $(document).ready(mkdfOnDocumentReady);

    /*
     ** All functions to be called on $(window).load() should be in this function
     */
    function mkdfOnDocumentReady() {
        mkdfInitInteractivePair();
    }

    /*
    **	Boxes which reveal text on hover
    */
    function mkdfInitInteractivePair(){
        var container = $('.mkdf-interactive-pair-holder');
        if(container.length) {
            container.each(function(){
                var thisContainer = $(this);

                if(mkdf.windowWidth > 768){

                    var active_element = 0;

                    //appearance
                    thisContainer.appear(function(){
                        var coverItem = $(this).find('.mkdf-interactive-pair-item').eq(active_element);
                        var idleCoverItem = $(this).find('.mkdf-interactive-pair-item').not(':first');

                        coverItem.addClass('mkdf-ip-current');
                        idleCoverItem.each(function (l) {
                            var k = $(this);
                            setTimeout(function() {
                                k.addClass('appeared');
                            }, l*400); // delay 400 ms
                        });

                    }, {accX: 0, accY: mkdfGlobalVars.vars.mkdfElementAppearAmount});

                    thisContainer.find('.mkdf-interactive-pair-item').each(function(l){

                        var hoveredItem = $(this);
                        hoveredItem.hover(function() {
                            thisContainer.find('.mkdf-interactive-pair-item').removeClass('mkdf-ip-current');
                            hoveredItem.addClass('mkdf-ip-current');
                        });
                    });

                }else{
                    thisContainer.find('.mkdf-interactive-pair-item').removeClass('mkdf-ip-current');
                }

            });
        }
    }

})(jQuery);