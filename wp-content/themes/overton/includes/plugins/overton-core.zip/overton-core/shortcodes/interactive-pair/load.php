<?php

include_once OVERTON_CORE_SHORTCODES_PATH . '/interactive-pair/functions.php';
include_once OVERTON_CORE_SHORTCODES_PATH . '/interactive-pair/interactive-pair.php';