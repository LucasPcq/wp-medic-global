<?php $back_style = 'background-image: url('.$image_src.')'?>
<?php $back_style_right = 'background-image: url('.$image_src_right.')'?>
<div class = "mkdf-interactive-pair-item">
    <div class="mkdf-interactive-pair-thumb">
        <span class="mkdf-interactive-pair-frame frame-1"></span>
        <span class="mkdf-interactive-pair-frame frame-2"></span>
        <span class="mkdf-interactive-pair-frame frame-3"></span>
        <span class="mkdf-interactive-pair-frame frame-4"></span>
        <?php echo wp_get_attachment_image($image, 'full'); ?>
    </div>
    <div class="mkdf-interactive-pair-content">
        <h5 class="mkdf-interactive-pair-title">
            <?php if(!empty($link)) : ?>
                <a itemprop="url" href="<?php echo esc_url($link); ?>" target="_self">
            <?php endif; ?>
            <?php echo esc_attr($title)?>
            <?php if(!empty($link)) : ?>
                </a>
            <?php endif; ?>
        </h5>
        <span class="mkdf-interactive-pair-subtitle">
            <?php echo esc_attr($subtitle)?>
        </span>
        <p class="mkdf-interactive-pair-text">
            <?php echo esc_attr($text)?>
        </p>
    </div>
</div>
<div class = "mkdf-interactive-pair-item mkdf-ipi-right">
    <div class="mkdf-interactive-pair-thumb">
        <span class="mkdf-interactive-pair-frame frame-1"></span>
        <span class="mkdf-interactive-pair-frame frame-2"></span>
        <span class="mkdf-interactive-pair-frame frame-3"></span>
        <span class="mkdf-interactive-pair-frame frame-4"></span>
        <?php echo wp_get_attachment_image($image_right, 'full'); ?>
    </div>
    <div class="mkdf-interactive-pair-content">
        <h5 class="mkdf-interactive-pair-title">
            <?php if(!empty($link_right)) : ?>
                <a itemprop="url" href="<?php echo esc_url($link); ?>" target="_self">
            <?php endif; ?>
            <?php echo esc_attr($title_right)?>
            <?php if(!empty($link_right)) : ?>
                </a>
            <?php endif; ?>
        </h5>
        <span class="mkdf-interactive-pair-subtitle">
            <?php echo esc_attr($subtitle_right)?>
        </span>
        <p class="mkdf-interactive-pair-text">
            <?php echo esc_attr($text_right)?>
        </p>
        <?php if($link_label_right !=''){ ?>
            <?php echo overton_mikado_get_button_html(array(
                'type' => 'simple',
                'link' => $link_right,
                'target' => $target,
                'text' => $link_label_right,
                'icon_pack' => 'font_elegant',
                'fe_icon'	=> 'arrow_right'
            ))?>
        <?php }?>
    </div>
</div>